from pathlib import Path
from src.generator import SyntheticDataGenerator
from src.store_json import JsonStore
from src.store_xml import XmlStore

def test_generator_and_json_store(tmp_path: Path):
    people = SyntheticDataGenerator.generate(5, seed=123, min_age=20, max_age=40)
    json_path = tmp_path / "people.json"
    store = JsonStore(json_path)

    store.save(people)
    loaded = store.load()
    assert len(loaded) == 5
    assert loaded[0].id == 1

def test_append_unique_json(tmp_path: Path):
    people1 = SyntheticDataGenerator.generate(3, seed=1)
    people2 = SyntheticDataGenerator.generate(3, seed=2)
    json_path = tmp_path / "people.json"
    store = JsonStore(json_path)

    store.save(people1)
    store.append_unique(people2)
    loaded = store.load()
    assert len(loaded) == 6

def test_generator_and_xml_store(tmp_path: Path):
    people = SyntheticDataGenerator.generate(5, seed=321)
    xml_path = tmp_path / "people.xml"
    store = XmlStore(xml_path)

    store.save(people)
    loaded = store.load()
    assert len(loaded) == 5
    assert loaded[0].id == 1
