from pathlib import Path
from typing import List
import xml.etree.ElementTree as ET
from xml.dom import minidom
from .models import Person
from .store_base import DataStore

class XmlStore(DataStore):
    def __init__(self, path: Path):
        self.path = path

    def save(self, people: List[Person]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        root = ET.Element("people")

        for p in people:
            person_el = ET.Element("person", attrib={"id": str(p.id)})
            for key, value in p.to_dict().items():
                if key == "id":
                    continue
                el = ET.SubElement(person_el, key)
                el.text = str(value)
            root.append(person_el)

        rough = ET.tostring(root, "utf-8")
        pretty = minidom.parseString(rough).toprettyxml(indent="  ")

        with self.path.open("w", encoding="utf-8") as f:
            f.write(pretty)

    def load(self) -> List[Person]:
        if not self.path.exists():
            return []
        tree = ET.parse(self.path)
        root = tree.getroot()
        people = []
        for person_el in root.findall("person"):
            data = {"id": person_el.attrib["id"]}
            for child in person_el:
                if child.tag == "tags":
                    data["tags"] = child.text.strip("[]").replace("'", "").split(", ") if child.text else []
                else:
                    data[child.tag] = child.text
            people.append(Person.from_dict(data))
        return people

    def append_unique(self, people: List[Person]) -> None:
        existing = {p.id for p in self.load()}
        new_people = [p for p in people if p.id not in existing]
        all_people = self.load() + new_people
        self.save(all_people)
