from abc import ABC, abstractmethod
from typing import List
from .models import Person

class DataStore(ABC):
    @abstractmethod
    def save(self, people: List[Person]) -> None:
        pass

    @abstractmethod
    def load(self) -> List[Person]:
        pass

    @abstractmethod
    def append_unique(self, people: List[Person]) -> None:
        pass
