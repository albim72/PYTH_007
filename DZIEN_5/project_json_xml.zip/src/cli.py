import argparse
from pathlib import Path
from .generator import SyntheticDataGenerator
from .store_json import JsonStore
from .store_xml import XmlStore

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--format", choices=["json", "xml"], required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--n", type=int, required=True)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--min-age", type=int, default=18)
    parser.add_argument("--max-age", type=int, default=80)

    args = parser.parse_args()

    people = SyntheticDataGenerator.generate(args.n, args.seed, args.min_age, args.max_age)

    if args.format == "json":
        store = JsonStore(args.out)
    else:
        store = XmlStore(args.out)

    store.save(people)
    print(f"Saved {len(people)} records to {args.out}")

if __name__ == "__main__":
    main()
