import json
from pathlib import Path
from typing import List
from .models import Person
from .store_base import DataStore

class JsonStore(DataStore):
    def __init__(self, path: Path):
        self.path = path

    def save(self, people: List[Person]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("w", encoding="utf-8") as f:
            json.dump([p.to_dict() for p in people], f, ensure_ascii=False, indent=4)

    def load(self) -> List[Person]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as f:
            data = json.load(f)
            return [Person.from_dict(d) for d in data]

    def append_unique(self, people: List[Person]) -> None:
        existing = {p.id for p in self.load()}
        new_people = [p for p in people if p.id not in existing]
        all_people = self.load() + new_people
        self.save(all_people)
