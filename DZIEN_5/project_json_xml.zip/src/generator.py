import random
from datetime import datetime, timedelta
from typing import List
from .models import Person

class SyntheticDataGenerator:
    first_names = ["Jan", "Anna", "Piotr", "Maria", "Krzysztof", "Ewa"]
    last_names = ["Kowalski", "Nowak", "Wiśniewski", "Wójcik", "Kamińska", "Lewandowski"]

    @staticmethod
    def generate(n: int, seed: int = None, min_age: int = 18, max_age: int = 80) -> List[Person]:
        if seed is not None:
            random.seed(seed)

        people = []
        for i in range(1, n + 1):
            fn = random.choice(SyntheticDataGenerator.first_names)
            ln = random.choice(SyntheticDataGenerator.last_names)
            age = random.randint(min_age, max_age)
            email = f"{fn.lower()}.{ln.lower()}{i}@example.com"
            registered_at = datetime.now() - timedelta(days=random.randint(0, 3650))
            tags = random.sample(["vip", "new", "inactive", "premium"], k=random.randint(0, 2))

            people.append(Person(
                id=i, first_name=fn, last_name=ln, email=email,
                age=age, registered_at=registered_at, tags=tags
            ))
        return people
