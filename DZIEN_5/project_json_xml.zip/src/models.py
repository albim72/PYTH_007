from dataclasses import dataclass, field
from datetime import datetime
from typing import List

@dataclass
class Person:
    id: int
    first_name: str
    last_name: str
    email: str
    age: int
    registered_at: datetime
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "email": self.email,
            "age": self.age,
            "registered_at": self.registered_at.isoformat(),
            "tags": self.tags,
        }

    @staticmethod
    def from_dict(data: dict) -> "Person":
        return Person(
            id=int(data["id"]),
            first_name=data["first_name"],
            last_name=data["last_name"],
            email=data["email"],
            age=int(data["age"]),
            registered_at=datetime.fromisoformat(data["registered_at"]),
            tags=list(data.get("tags", [])),
        )
